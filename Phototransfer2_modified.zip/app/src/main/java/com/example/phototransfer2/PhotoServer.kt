package com.example.phototransfer2

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * PhotoServer è un server HTTP minimale basato su NanoHTTPD per condividere
 * foto e video attraverso la rete locale.
 *
 * Espone tre percorsi:
 *  - "/"         : una pagina HTML con l'elenco dei file selezionati e link
 *    per il download individuale e per scaricare un archivio ZIP.
 *  - "/photo/{i}": stream del file i-esimo selezionato.
 *  - "/zip"      : genera al volo un archivio ZIP contenente tutti i file.
 */
class PhotoServer(private val ctx: Context, port: Int = 8080) : NanoHTTPD(port) {

    private val uris = mutableListOf<Uri>()

    /**
     * Aggiorna l'elenco di URI dei file da servire.
     */
    fun setPhotos(newUris: List<Uri>) {
        uris.clear()
        uris.addAll(newUris)
    }

    override fun serve(session: IHTTPSession): Response {
        val path = URLDecoder.decode(session.uri, "UTF-8")
        return when {
            path == "/" -> galleryHtml()
            path == "/zip" -> zipAll()
            path.startsWith("/photo/") -> servePhoto(path.removePrefix("/photo/"))
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        }
    }

    /**
     * Restituisce una pagina HTML con l'elenco dei file condivisi e link di download.
     */
    private fun galleryHtml(): Response {
        val html = buildString {
            append("<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>")
            append("<style>body{font-family:sans-serif;padding:16px} .card{margin:12px 0;padding:12px;border:1px solid #ddd;border-radius:12px}</style>")
            append("</head><body>")
            append("<h2>Foto/Video condivisi</h2>")
            append("<p><a href='/zip'>📦 Scarica tutto (ZIP)</a></p>")
            uris.forEachIndexed { i, _ ->
                append("<div class='card'>Item $i — <a href='/photo/$i'>⬇️ Scarica</a></div>")
            }
            append("</body></html>")
        }
        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
    }

    /**
     * Serve un singolo file indicizzato dall'URI.
     */
    private fun servePhoto(indexStr: String): Response {
        val idx = indexStr.toIntOrNull()
            ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "Bad index")
        if (idx !in uris.indices) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        }

        val uri = uris[idx]
        val mime = mimeOf(uri, ctx.contentResolver)
        val input: InputStream = ctx.contentResolver.openInputStream(uri)
            ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "IO error")

        val resp = newChunkedResponse(Response.Status.OK, mime, input)
        resp.addHeader("Content-Disposition", "attachment; filename=\"item_${idx}${extFromMime(mime)}\"")
        return resp
    }

    /**
     * Genera un archivio ZIP contenente tutti i media selezionati.
     */
    private fun zipAll(): Response {
        val piped = java.io.PipedInputStream()
        val out = java.io.PipedOutputStream(piped)

        Thread {
            ZipOutputStream(out).use { zos ->
                uris.forEachIndexed { i, uri ->
                    val mime = mimeOf(uri, ctx.contentResolver)
                    val entry = ZipEntry("item_${i}${extFromMime(mime)}")
                    zos.putNextEntry(entry)
                    ctx.contentResolver.openInputStream(uri)?.use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }.start()

        val resp = newChunkedResponse(Response.Status.OK, "application/zip", piped)
        resp.addHeader("Content-Disposition", "attachment; filename=\"items_today.zip\"")
        return resp
    }

    /**
     * Ricava il MIME type di un URI.
     */
    private fun mimeOf(uri: Uri, cr: ContentResolver): String =
        cr.getType(uri) ?: "application/octet-stream"

    /**
     * Restituisce l'estensione corrispondente a un MIME type.
     */
    private fun extFromMime(mime: String) = when (mime) {
        "image/jpeg" -> ".jpg"
        "image/png"  -> ".png"
        "image/heic", "image/heif" -> ".heic"
        "video/mp4"  -> ".mp4"
        "video/quicktime" -> ".mov"
        else -> ""
    }
}