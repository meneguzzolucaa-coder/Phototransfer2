package com.example.phototransfer2

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.format.Formatter
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var selectButton: Button
    private lateinit var shareButton: Button
    private lateinit var zipButton: Button
    private lateinit var todayButton: Button
    private lateinit var listView: ListView

    private val selectedUris = mutableListOf<Uri>()
    private var server: PhotoServer? = null

    companion object {
        private const val REQUEST_PICK = 2001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        selectButton = findViewById(R.id.btn_select)
        shareButton  = findViewById(R.id.btn_share)
        zipButton    = findViewById(R.id.btn_zip)
        todayButton  = findViewById(R.id.btn_today)
        listView     = findViewById(R.id.list_photos)

        shareButton.isEnabled = false
        zipButton.isEnabled   = false

        selectButton.setOnClickListener { openPicker() }

        shareButton.setOnClickListener {
            if (selectedUris.isEmpty()) {
                Toast.makeText(this, "Seleziona prima almeno una foto", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startServerAndShowQr("/")
        }

        zipButton.setOnClickListener {
            if (selectedUris.isEmpty()) {
                Toast.makeText(this, "Seleziona prima almeno una foto", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startServerAndShowQr("/zip")
        }

        todayButton.setOnClickListener {
            val todayUris = collectTodayMediaUris()
            if (todayUris.isEmpty()) {
                Toast.makeText(this, "Nessun media trovato da mezzanotte", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            selectedUris.clear()
            selectedUris.addAll(todayUris)
            listView.adapter = ArrayAdapter(
                this, android.R.layout.simple_list_item_1, todayUris.map { it.toString() }
            )
            shareButton.isEnabled = true
            zipButton.isEnabled   = true
            if (server == null) server = PhotoServer(this, 8080)
            server!!.setPhotos(selectedUris)
            server!!.start()
            showQrDialog("Scarica foto/video di oggi", "http://${localIp(this)}:8080/zip")
        }
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(Intent.createChooser(intent, "Scegli immagini"), REQUEST_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PICK || data == null) return

        selectedUris.clear()
        val clip: ClipData? = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                val uri = clip.getItemAt(i).uri
                persistRead(uri)
                selectedUris.add(uri)
            }
        } else {
            data.data?.let {
                persistRead(it)
                selectedUris.add(it)
            }
        }

        val labels = selectedUris.map { getBestLabel(it) }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)

        val enabled = selectedUris.isNotEmpty()
        shareButton.isEnabled = enabled
        zipButton.isEnabled   = enabled
    }

    private fun persistRead(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) { }
    }

    private fun getBestLabel(uri: Uri): String {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIdx >= 0 && c.moveToFirst()) c.getString(nameIdx) else uri.toString()
            } ?: uri.toString()
        } catch (_: Exception) { uri.toString() }
    }

    private fun startServerAndShowQr(path: String) {
        if (server == null) server = PhotoServer(this, 8080)
        server!!.setPhotos(selectedUris)
        server!!.start()
        showQrDialog(
            if (path == "/") "Condividi foto" else "Scarica lo ZIP",
            "http://${localIp(this)}:8080$path"
        )
    }

    private fun showQrDialog(title: String, url: String) {
        Toast.makeText(this, url, Toast.LENGTH_LONG).show()
        val imageView = ImageView(this).apply { setImageBitmap(qrBitmap(url)) }
        AlertDialog.Builder(this).setTitle("$title\n$url").setView(imageView)
            .setPositiveButton("OK", null).show()
    }

    override fun onDestroy() { super.onDestroy(); server?.stop() }

    private fun collectTodayMediaUris(): List<Uri> {
        val midnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val uris = mutableListOf<Uri>()
        val args = arrayOf((midnight / 1000).toString())

        // Images
        contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED),
            MediaStore.Images.Media.DATE_ADDED + " >= ?", args, null
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                uris.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString()))
            }
        }
        // Videos
        contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DATE_ADDED),
            MediaStore.Video.Media.DATE_ADDED + " >= ?", args, null
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                uris.add(Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()))
            }
        }

        uris.forEach { persistRead(it) }
        return uris
    }
}

// Helpers
private fun localIp(context: Context): String {
    val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    @Suppress("DEPRECATION")
    return Formatter.formatIpAddress(wm.connectionInfo.ipAddress)
}
private fun qrBitmap(text: String, size: Int = 512): Bitmap {
    val bits = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    for (x in 0 until size) for (y in 0 until size)
        bmp.setPixel(x, y, if (bits[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
    return bmp
}
