package com.example.phototransfer

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.phototransfer.core.network.NetUtils
import com.example.phototransfer.features.sharing.LanShareManager

class MainActivity : AppCompatActivity() {
    private val shareManager = LanShareManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        val ipList = try { NetUtils.localIPv4().joinToString() } catch (e: Exception) { "unknown" }
        tv.text = "Phototransfer ready\nLocal IPs: " + ipList
        setContentView(tv)
    }
}
