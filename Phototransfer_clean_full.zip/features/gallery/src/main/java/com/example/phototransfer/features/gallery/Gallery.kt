package com.example.phototransfer.features.gallery

import android.content.Context
import android.net.Uri

object Gallery {
    /** Placeholder for future Photo Picker integration. */
    fun pickPhotoPlaceholder(context: Context): Uri? {
        // TODO: integrate Android Photo Picker
        return null
    }
}
