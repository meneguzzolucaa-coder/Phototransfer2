package com.example.phototransfer.features.sharing

/** Minimal stub that represents LAN sharing start/stop. */
class LanShareManager {
    fun start() {
        // TODO: implement HTTP server for LAN sharing (e.g., NanoHTTPD or Ktor)
    }
    fun stop() {
        // TODO: stop server and release resources
    }
    fun isRunning(): Boolean = false
}
