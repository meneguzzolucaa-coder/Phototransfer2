package com.example.phototransfer.core.network

import java.net.NetworkInterface

object NetUtils {
    /** Returns a list of local IPv4 addresses (non-loopback). */
    fun localIPv4(): List<String> {
        val result = mutableListOf<String>()
        val en = NetworkInterface.getNetworkInterfaces()
        while (en.hasMoreElements()) {
            val iface = en.nextElement()
            val addrs = iface.inetAddresses
            while (addrs.hasMoreElements()) {
                val addr = addrs.nextElement()
                val host = addr.hostAddress
                if (!addr.isLoopbackAddress && host.indexOf(':') < 0) {
                    result.add(host)
                }
            }
        }
        return result
    }
}
