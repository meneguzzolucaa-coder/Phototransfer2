
# Phototransfer (clean, multi-module)

Condivisione foto su rete locale (LAN) — base di progetto pulita e modulare.

## Requisiti
- Android Studio **Jellyfish** o superiore
- **JDK 17**
- Gradle Wrapper (se non presente: `gradle wrapper --gradle-version 8.7`)

## Moduli
- `app/` – applicazione Android (UI minimale)
- `core/network` – utilità di rete (es. IP locali)
- `features/sharing` – stub per server LAN (start/stop)
- `features/gallery` – stub per Photo Picker

## Build
```bash
./gradlew assembleDebug
```

## CI
- `.github/workflows/ci.yml` – build/lint/test su push/PR
- `.github/workflows/release.yml` – build release su tag `vX.Y.Z` e rilascio APK come artifact

## Permessi Android
- `INTERNET`, `ACCESS_NETWORK_STATE` per rete locale
- `READ_MEDIA_IMAGES` (Android 13+), `READ_EXTERNAL_STORAGE` (<=12, maxSdk 32)

## TODO (per evolvere)
- Integrare un server HTTP embedded (es. NanoHTTPD/Ktor)
- Photo Picker reale + runtime permissions
- UI (Compose o Views) con schermate per “Condividi / Ricevi”
- Logging, error handling, test strumentali.
